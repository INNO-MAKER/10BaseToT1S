savedcmd_/home/pi/linux-v6.1.21-support/modules.order := {   echo /home/pi/linux-v6.1.21-support/microchip_t1s.o; :; } > /home/pi/linux-v6.1.21-support/modules.order
