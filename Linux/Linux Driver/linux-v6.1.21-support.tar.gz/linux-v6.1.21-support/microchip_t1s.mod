/home/pi/linux-v6.1.21-support/microchip_t1s.o
