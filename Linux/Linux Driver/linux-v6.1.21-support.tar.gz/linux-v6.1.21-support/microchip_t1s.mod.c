#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

#ifdef CONFIG_UNWINDER_ORC
#include <asm/orc_header.h>
ORC_HEADER;
#endif

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x2b2bc5d9, "phy_drivers_register" },
	{ 0x866dbf41, "phy_drivers_unregister" },
	{ 0x6a5c8d0b, "phy_write_mmd" },
	{ 0x23ecbf8c, "phy_read_mmd" },
	{ 0x60a6cfd3, "phy_modify_mmd" },
	{ 0x46d2810, "_dev_info" },
	{ 0x6530bc32, "mdiobus_read" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x197f0d7b, "_dev_err" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xa538bc62, "param_ops_byte" },
	{ 0x11fb43f9, "param_ops_bool" },
	{ 0xe478ef45, "module_layout" },
};

MODULE_INFO(depends, "");

MODULE_ALIAS("mdio:00000000000001111100000101100010");
MODULE_ALIAS("mdio:00000000000001111100000101100011");
MODULE_ALIAS("mdio:00000000000001111100000101100100");
MODULE_ALIAS("mdio:00000000000001111100000101100101");
MODULE_ALIAS("mdio:00000000000001111100000110110011");

MODULE_INFO(srcversion, "B01AFC397B5DE8BFE001C7B");
